java -cp homeworkduino.jar -Djava.library.path=. bzb.se.ui.Graphical /dev/ttyUSB0 1
pause