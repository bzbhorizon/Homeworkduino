java -cp homeworkduino.jar -Djava.library.path=. bzb.se.ui.Command /dev/ttyUSB0 1
pause